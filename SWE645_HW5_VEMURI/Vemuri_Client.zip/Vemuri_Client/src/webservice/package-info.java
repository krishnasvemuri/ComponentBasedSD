//Krishna Sindhuri Vemuri -G01024066
@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservice/")
package webservice;
