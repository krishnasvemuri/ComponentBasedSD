//Krishna Sindhuri Vemuri -G01024066
package webservice;
public class StudentService {
	
	
	


	public String getResult(double mean) {
		if(mean>=90.0){
			return "WinnerAcknowledgement";
		}
		else{
			return "SimpleAcknowledgement";
			
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
