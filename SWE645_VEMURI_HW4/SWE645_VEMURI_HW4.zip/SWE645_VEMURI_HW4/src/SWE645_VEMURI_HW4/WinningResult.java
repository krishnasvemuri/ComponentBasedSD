//Krishna Sindhuri Vemuri G01024066 SWE_645_HW4
//This is the WinningResult data model
package SWE645_VEMURI_HW4;

public class WinningResult {
	double mean;
	double deviation;

	
	public double getMean() {
		return mean;
	}

	public void setMean(double mean) {
		this.mean = mean;
	}

	public double getDeviation() {
		return deviation;
	}

	public void setDeviation(double deviation) {
		this.deviation = deviation;
	}

}
